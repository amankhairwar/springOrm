package com.spring.orm;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.spring.orm.Dao.StudentDao;
import com.spring.orm.Entities.Student;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	ApplicationContext context=new ClassPathXmlApplicationContext("com/spring/orm/config.xml");
    	StudentDao dao= context.getBean("studentDao",StudentDao.class);
    	Student student = new Student(1,"aman khairwar","Mumbai");
    	int res=dao.insert(student);
    	System.out.println("rows affected "+res);
    }
}
