package com.spring.orm.Dao;

import javax.transaction.Transactional;

import org.springframework.orm.hibernate5.HibernateTemplate;

import com.spring.orm.Entities.Student;

public class StudentDao {
	private HibernateTemplate template;
	public HibernateTemplate getTemplate() {
		return template;
	}
	public void setTemplate(HibernateTemplate template) {
		this.template = template;
	}
	@Transactional
	public int insert(Student s) {
		Integer i=(Integer)this.template.save(s);
		return i;
	}
}
